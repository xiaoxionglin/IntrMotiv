import numpy as np
import pytest
import torch

from sf_working_directories.IntrMotiv.dmlab.dg_neighborhood import (
    NeighborhoodConfig, enclosure_masks, episode_segments, local_pairs,
    cross_unit_repulsion, neighborhood_losses,
)


def test_heading_aligned_ellipse_and_wrap():
    cfg = NeighborhoodConfig()
    anchors = torch.tensor([[0., 0., 0.], [0., 0., 90.], [0., 0., 359.]])
    obs = torch.tensor([[140., 0., 0.], [0., 140., 90.], [0., 0., 1.], [0., 0., 30.]])
    positive, negative = enclosure_masks(anchors, obs, cfg)
    assert positive[0, 0] and positive[1, 1] and positive[2, 2]
    assert negative[3, 0] and not positive[0, 1]
    p, n = enclosure_masks(anchors[:1], torch.tensor([[200., 0., 0.]]), cfg)
    assert not p.item() and not n.item()


def test_own_unit_gradients_reach_silent_neighbors_and_suppress_far_sample():
    scores = torch.tensor([[2., -2.], [-1., -3.], [-1., -4.]], requires_grad=True)
    pose = torch.tensor([[0., 0., 0.], [10., 0., 0.], [500., 0., 0.]])
    loss, rep, stats = neighborhood_losses(scores, pose, torch.ones(3, dtype=torch.bool),
        torch.zeros(3, dtype=torch.bool), 3, NeighborhoodConfig())
    loss.backward()
    assert scores.grad[1, 0] < 0 and scores.grad[2, 0] > 0
    assert torch.equal(scores.grad[:, 1], torch.zeros(3))
    assert scores.grad[0, 0] == 0  # anchor itself is excluded
    assert stats["anchor_count"] == 1 and rep == 0


def test_segments_do_not_cross_resets_or_invalid_observations():
    segments = episode_segments([1, 1, 0, 1, 1, 1, 1, 1], [1, 0, 0, 0, 0, 0, 0, 0], 4)
    assert [s.tolist() for s in segments] == [[0], [1], [3], [4, 5, 6, 7]]
    pairs, _ = local_pairs(np.zeros((8, 3)), segments, NeighborhoodConfig(repulsion="temporal"), 99)
    assert pairs.tolist() == [[4, 5], [5, 6], [6, 7]]


def test_sampled_physical_pairs_are_bounded_distinct_and_reproducible():
    pose = np.array([[0, 0, 0], [0, 0, 180], [90, 0, 0], [500, 0, 0]], float)
    cfg = NeighborhoodConfig(repulsion="physical")
    pairs, weights = local_pairs(pose, [np.arange(4)], cfg, 99)
    assert np.array_equal(pairs, local_pairs(pose, [np.arange(4)], cfg, 99)[0])
    assert len(pairs) == 3 and len(np.unique(pairs[:, 0])) == 3
    assert np.all(pairs[:, 0] != pairs[:, 1]) and np.all(np.isfinite(weights))
    assert np.all(np.linalg.norm(pose[pairs[:, 0], :2] - pose[pairs[:, 1], :2], axis=1) <= 100)
    assert np.all(weights <= 10)


def test_repulsion_matches_explicit_off_diagonal_and_gradients():
    a = torch.tensor([[1., 2., 0.], [3., 0., 4.]], requires_grad=True)
    actual = cross_unit_repulsion(a, [[0, 1]], [2.])
    reference = 2 * sum(a[0, i] * a[1, j] for i in range(3) for j in range(3) if i != j)
    assert torch.equal(actual, reference)
    assert torch.equal(torch.autograd.grad(actual, a)[0], torch.autograd.grad(reference, a)[0])
    assert cross_unit_repulsion(torch.tensor([[1., 0.], [2., 0.]]), [[0, 1]], [1.]) == 0


def test_silent_population_and_singleton_are_finite_differentiable():
    scores = torch.full((2, 3), -1., requires_grad=True)
    loss, rep, stats = neighborhood_losses(scores, torch.zeros(2, 3), torch.ones(2, dtype=torch.bool),
        torch.ones(2, dtype=torch.bool), 2, NeighborhoodConfig(repulsion="physical"))
    (loss + rep).backward()
    assert loss == 0 and rep == 0 and stats["anchor_count"] == 0
    assert torch.equal(scores.grad, torch.zeros_like(scores))


def test_strongest_anchor_tie_uses_first_and_ignores_other_anchor():
    scores = torch.tensor([[2.], [2.], [-1.]], requires_grad=True)
    pose = torch.tensor([[0., 0., 0.], [500., 0., 0.], [10., 0., 0.]])
    loss, _, _ = neighborhood_losses(scores, pose, torch.ones(3, dtype=torch.bool),
        torch.zeros(3, dtype=torch.bool), 3, NeighborhoodConfig())
    loss.backward()
    assert scores.grad[0] == 0 and scores.grad[1] > 0 and scores.grad[2] < 0


@pytest.mark.parametrize("device", ["cpu", "cuda"])
def test_progression_preserves_device(device):
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("CUDA is required for the GPU portability gate")
    from sf_working_directories.IntrMotiv.dmlab.custom_learner import BaseDistanceRecorder
    sequence = torch.tensor([[[0, 1, 0], [0, 0, 0]]], device=device)
    actual = BaseDistanceRecorder._calculate_progression(None, sequence)
    assert actual.device.type == device
    assert actual.tolist() == [1, 3]
