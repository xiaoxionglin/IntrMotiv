"""Activation-anchored DG supervision and sampled, cross-unit local repulsion.

Coordinates are raw DMLab world x/y and yaw in degrees. Labels and anchor
selection are detached; only DG scores/activities participate in autograd.
The loss deliberately does not recruit a unit silent for an entire segment.
"""
from dataclasses import dataclass

import numpy as np
from scipy.spatial import cKDTree
import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class NeighborhoodConfig:
    positive_along: float = 150.0
    positive_across: float = 100.0
    negative_along: float = 300.0
    negative_across: float = 200.0
    positive_angle: float = 15.0
    negative_angle: float = 30.0
    margin: float = 1.0
    negative_weight: float = 1.0
    repulsion: str = "none"
    repulsion_coefficient: float = 0.1
    repulsion_radius: float = 100.0
    distance_floor: float = 10.0

    def __post_init__(self):
        if not (0 < self.positive_along < self.negative_along and
                0 < self.positive_across < self.negative_across and
                0 <= self.positive_angle < self.negative_angle <= 180):
            raise ValueError("Positive enclosure must be strictly inside the outer enclosure")
        if self.repulsion not in ("none", "temporal", "physical"):
            raise ValueError("Unknown local repulsion mode")
        if min(self.margin, self.negative_weight, self.repulsion_coefficient) < 0:
            raise ValueError("Loss margins and weights must be nonnegative")
        if not 0 < self.distance_floor <= self.repulsion_radius:
            raise ValueError("Require 0 < distance floor <= repulsion radius")


def episode_segments(valids, dones, recurrence):
    """Return contiguous valid segments; done[t] separates t from t+1."""
    valid = np.asarray(valids, dtype=bool).reshape(-1)
    done = np.asarray(dones, dtype=bool).reshape(-1)
    if len(valid) != len(done) or recurrence < 1 or len(valid) % recurrence:
        raise ValueError("Aligned complete recurrence chunks are required")
    segments = []
    for base in range(0, len(valid), recurrence):
        current = []
        for t in range(base, base + recurrence):
            if valid[t]:
                current.append(t)
            if not valid[t] or done[t] or t == base + recurrence - 1:
                if current:
                    segments.append(np.asarray(current, dtype=np.int64))
                current = []
    return segments


def enclosure_masks(anchors, observations, cfg):
    """Return [observations, anchors] positive/negative masks, ignoring yaw wrap."""
    delta = observations[:, None, :2] - anchors[None, :, :2]
    yaw = torch.deg2rad(anchors[:, 2])
    along = delta[..., 0] * yaw.cos() + delta[..., 1] * yaw.sin()
    across = -delta[..., 0] * yaw.sin() + delta[..., 1] * yaw.cos()
    angle = ((observations[:, None, 2] - anchors[None, :, 2] + 180) % 360 - 180).abs()
    inner = (along / cfg.positive_along).square() + (across / cfg.positive_across).square()
    outer = (along / cfg.negative_along).square() + (across / cfg.negative_across).square()
    return (inner <= 1) & (angle <= cfg.positive_angle), (outer > 1) | (angle >= cfg.negative_angle)


def local_pairs(pose, segments, cfg, seed):
    """Sample at most one partner per observation without a dense distance matrix."""
    pairs, weights = [], []
    rng = np.random.default_rng(seed)
    if cfg.repulsion == "none":
        return np.empty((0, 2), dtype=np.int64), np.empty(0, dtype=np.float32)
    for segment in segments:
        if cfg.repulsion == "temporal":
            pairs.extend(zip(segment[:-1], segment[1:]))
            weights.extend([1.0] * (len(segment) - 1))
            continue
        positions = pose[segment, :2]
        tree = cKDTree(positions)
        for t, point in enumerate(positions):
            candidates = [u for u in tree.query_ball_point(point, cfg.repulsion_radius) if u != t]
            if candidates:
                u = int(rng.choice(candidates))
                pairs.append((segment[t], segment[u]))
                distance = np.linalg.norm(point - positions[u])
                weights.append(cfg.repulsion_radius / max(float(distance), cfg.distance_floor))
    return np.asarray(pairs, dtype=np.int64).reshape(-1, 2), np.asarray(weights, dtype=np.float32)


def cross_unit_repulsion(activity, pairs, weights):
    """Exact off-diagonal product sum in O(number of sampled pairs * DG width)."""
    if len(pairs) == 0:
        return activity.sum() * 0.0
    indices = torch.as_tensor(pairs, device=activity.device, dtype=torch.long)
    weights = torch.as_tensor(weights, device=activity.device, dtype=activity.dtype)
    left, right = activity[indices[:, 0]], activity[indices[:, 1]]
    return (weights * (left.sum(-1) * right.sum(-1) - (left * right).sum(-1))).mean()


def neighborhood_losses(scores, pose, valids, dones, recurrence, cfg, seed=0):
    """Return self loss, weighted repulsion, and detached diagnostics.

    Each unit's segment means receive equal weight, then all units are averaged.
    A segment without an active anchor is absent from that unit's segment mean;
    a unit with no anchor contributes zero to the fixed population denominator.
    """
    if scores.ndim != 2 or pose.shape != (scores.shape[0], 3):
        raise ValueError("Expected aligned [N,F] scores and raw [N,3] poses")
    valid_cpu = valids.detach().cpu().numpy().astype(bool)
    pose_cpu = pose.detach().cpu().numpy()
    if not np.isfinite(pose_cpu[valid_cpu]).all():
        raise ValueError("Nonfinite pose in a valid training observation")
    segments = episode_segments(valid_cpu, dones.detach().cpu().numpy(), recurrence)
    pose = pose.detach().to(device=scores.device, dtype=scores.dtype)
    activity = scores.relu()
    units = scores.shape[1]
    total = scores.sum(0) * 0.0
    counts = scores.new_zeros(units)
    positive_count = scores.new_zeros(())
    negative_count = scores.new_zeros(())
    positive_hits = scores.new_zeros(())
    negative_hits = scores.new_zeros(())
    anchor_strength = scores.new_zeros(())
    for segment in segments:
        ix = torch.as_tensor(segment, device=scores.device)
        values = scores[ix]
        peaks, anchors = values.detach().max(0)
        anchored = peaks > 0
        positive, negative = enclosure_masks(pose[ix[anchors]], pose[ix], cfg)
        not_self = torch.arange(len(segment), device=scores.device)[:, None] != anchors[None, :]
        positive &= anchored[None, :] & not_self
        negative &= anchored[None, :] & not_self
        pcount, ncount = positive.sum(0), negative.sum(0)
        unit_loss = (F.softplus(cfg.margin - values) * positive).sum(0) / pcount.clamp_min(1)
        unit_loss += cfg.negative_weight * (F.softplus(cfg.margin + values) * negative).sum(0) / ncount.clamp_min(1)
        total = total + unit_loss
        counts += anchored
        positive_count += pcount.sum()
        negative_count += ncount.sum()
        positive_hits += ((values.detach() > 0) & positive).sum()
        negative_hits += ((values.detach() > 0) & negative).sum()
        anchor_strength += peaks[anchored].sum()
    self_loss = (total / counts.clamp_min(1)).mean()
    pairs, weights = local_pairs(pose_cpu, segments, cfg, seed)
    repulsion = cfg.repulsion_coefficient * cross_unit_repulsion(activity, pairs, weights)
    diagnostics = {
        "self_loss": self_loss.detach(), "repulsion_loss": repulsion.detach(),
        "anchored_unit_fraction": (counts > 0).float().mean(), "anchor_count": counts.sum(),
        "anchor_strength": anchor_strength / counts.sum().clamp_min(1),
        "positive_count": positive_count, "negative_count": negative_count,
        "positive_recall": positive_hits / positive_count.clamp_min(1),
        "false_positive_rate": negative_hits / negative_count.clamp_min(1),
        "pair_count": scores.new_tensor(len(pairs)),
    }
    return self_loss, repulsion, diagnostics
