"""Synthetic CPU microbenchmark; no environment, checkpoint, or training writes.

Pass an archived pre-optimization topological_frontier.py as --baseline.
This measures graph functions only, not end-to-end training FPS.
"""
import argparse
import copy
import importlib.util
import json
import statistics
import sys
import time
from types import SimpleNamespace

import torch
from sf_working_directories.IntrMotiv.dmlab import topological_frontier as optimized
from sf_working_directories.IntrMotiv.dmlab.hrl_controllable_graph import (
    PolicyControllableGraph, hrl_option_state_size,
)


def median_ms(fn, count=12):
    fn()
    times = []
    for _ in range(count):
        start = time.perf_counter()
        fn()
        times.append(1000 * (time.perf_counter() - start))
    return statistics.median(times)


def check_manager_replay(baseline, n):
    graph = PolicyControllableGraph(n)
    graph.node_visits.fill_(1)
    for i in range(n - 1):
        graph.tctrl[i, i + 1] = 2
        graph.edge_confidence[i, i + 1] = 3
        graph.control_attempts[i, i + 1] = 3
    for i in range(min(6, n)):
        graph.passive_confidence[i, (i + 2) % n] = 3
        graph.passive_time[i, (i + 2) % n] = 2
    new_graph = copy.deepcopy(graph)
    old_option = torch.zeros(2, hrl_option_state_size(n))
    old_topo = torch.zeros(2, optimized.topological_state_size(n))
    new_option, new_topo = old_option.clone(), old_topo.clone()
    for step in range(24):
        if step == 8:
            for g in (graph, new_graph):
                g.control_attempts.data[0, 1] = 50
                g.tctrl.data[1, 2] = 5
        if step == 16:
            for g in (graph, new_graph):
                g.invalidate_node(1)
        dg = torch.zeros(2, n)
        if step % 3 == 0:
            for row in range(2):
                target = int(old_option[row, 0]) - 1
                dg[row, target if 0 <= target < n else row] = 1
        kwargs = dict(fallback_horizon=3, margin_ratio=0.2, margin_steps=2,
                      confidence_threshold=0.5, passive_threshold=2.0,
                      passive_min_displacement=2.0, passive_max_length=64.0,
                      use_motion_filter=False, frontier_uncertainty_weight=1.0,
                      waypoint_planning=True, exploration_horizon=3,
                      target_timing='immediate', edge_exploration=True)
        actions = torch.zeros(2, 4)
        old = baseline.advance_topological_manager(old_option, old_topo, dg, actions, graph, **kwargs)
        new = optimized.advance_topological_manager(new_option, new_topo, dg, actions, new_graph, **kwargs)
        assert all(torch.equal(a, b) for a, b in zip(old, new)), (n, step)
        old_option, old_topo = old[:2]
        new_option, new_topo = new[:2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('graph_planning_baseline', args.baseline)
    baseline = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = baseline
    spec.loader.exec_module(baseline)
    torch.set_num_threads(1)
    rows = []
    for n in [16, 32, 64]:
        check_manager_replay(baseline, n)
        rng = torch.Generator().manual_seed(991 + n)
        known = torch.rand((n, n), generator=rng) < 0.02
        known.fill_diagonal_(False)
        graph = SimpleNamespace(n_nodes=n, tctrl=torch.rand((n, n), generator=rng) * 50 + 1,
                                edge_confidence=known.float() * 3, control_attempts=known.float() * 3)
        candidates = (torch.rand((n, n), generator=rng) < 0.10) & ~known
        candidates.fill_diagonal_(False)
        reachable = torch.ones(n, dtype=torch.bool)
        paths_old = lambda: baseline.validated_paths(graph, 0.5, 0.5)
        paths_new = lambda: optimized.validated_paths(graph, 0.5, 0.5)
        probe_old = lambda: baseline.select_connectivity_probe(graph, candidates, reachable, 0.5, 0.5)
        probe_new = lambda: optimized.select_connectivity_probe(graph, candidates, reachable, 0.5, 0.5)
        assert all(torch.equal(a, b) for a, b in zip(paths_old(), paths_new()))
        assert probe_old() == probe_new()
        def cold(fn):
            for name in ('_validated_paths_cache', '_connectivity_gains_cache'):
                if hasattr(graph, name):
                    delattr(graph, name)
            return fn()
        rows.append(dict(n=n, candidates=int(candidates.sum()),
                         paths_before_ms=median_ms(paths_old),
                         paths_cached_ms=median_ms(paths_new),
                         paths_rebuild_ms=median_ms(lambda: cold(paths_new)),
                         probe_before_ms=median_ms(probe_old),
                         probe_cached_ms=median_ms(probe_new),
                         probe_rebuild_ms=median_ms(lambda: cold(probe_new))))
    print(json.dumps(dict(kind='synthetic_graph_microbenchmark', torch=torch.__version__, threads=1,
                          seed_rule='991 + n', reliable_density=0.02, candidate_density=0.10,
                          reachable_sources='all', exact_outputs_match=True,
                          manager_replay='24 steps x 2 streams per DG size; hits, silence, expiry, graph updates, retirement',
                          rows=rows), indent=2))


if __name__ == '__main__':
    main()
