"""Behavior and invalidation contracts for graph-planning acceleration."""
from types import SimpleNamespace
from unittest.mock import patch

import pytest
import torch

from sf_working_directories.IntrMotiv.dmlab import topological_frontier as tf
from sf_working_directories.IntrMotiv.dmlab.hrl_controllable_graph import PolicyControllableGraph


def reference_reach(adjacency):
    # Independent graph traversal, not the matrix closure used in production.
    edges = adjacency.tolist()
    n = len(edges)
    result = torch.eye(n, dtype=torch.bool)
    for start in range(n):
        seen, pending = {start}, [start]
        while pending:
            current = pending.pop()
            for end, exists in enumerate(edges[current]):
                if exists and end not in seen:
                    seen.add(end)
                    pending.append(end)
        result[start, list(seen)] = True
    return result


def reference_gain(adjacency, source, destination):
    before = reference_reach(adjacency)
    after = adjacency.clone()
    after[source, destination] = True
    return float((reference_reach(after) & ~before).sum())


def graph(n):
    return SimpleNamespace(n_nodes=n, tctrl=torch.ones(n, n),
                           edge_confidence=torch.ones(n, n), control_attempts=torch.ones(n, n))


def test_exhaustive_three_node_gains():
    for bits in range(1 << 9):
        adjacency = torch.tensor([(bits >> k) & 1 for k in range(9)], dtype=torch.bool).view(3, 3)
        actual = tf._graph_connectivity_gains(SimpleNamespace(), adjacency)
        for source in range(3):
            for destination in range(3):
                expected = reference_gain(adjacency, source, destination)
                assert actual[source, destination] == expected
                assert tf.connectivity_gain(adjacency, source, destination) == expected


@pytest.mark.parametrize('n', [16, 32, 64])
def test_sparse_dense_disconnected_and_cyclic_gains(n):
    rng = torch.Generator().manual_seed(n)
    for density in [0.0, 0.015, 0.05, 0.5, 1.0]:
        adjacency = torch.rand((n, n), generator=rng) < density
        actual = tf._graph_connectivity_gains(SimpleNamespace(), adjacency)
        for source, destination in torch.randint(n, (12, 2), generator=rng).tolist():
            assert actual[source, destination] == reference_gain(adjacency, source, destination)


def test_probe_selection_and_ties_unchanged():
    rng = torch.Generator().manual_seed(471)
    for _ in range(12):
        g = graph(8)
        g.tctrl = (torch.rand((8, 8), generator=rng) < 0.15).float()
        g.control_attempts = torch.randint(0, 4, (8, 8), generator=rng).float()
        candidates = torch.rand((8, 8), generator=rng) < 0.5
        reachable = torch.rand(8, generator=rng) < 0.7
        actual = tf.select_connectivity_probe(g, candidates, reachable, 0.5, 0.5)
        def reference_matrix(unused, adjacency):
            return torch.tensor([[reference_gain(adjacency, s, d) for d in range(8)] for s in range(8)])
        with patch.object(tf, '_graph_connectivity_gains', side_effect=reference_matrix):
            assert tf.select_connectivity_probe(g, candidates, reachable, 0.5, 0.5) == actual
    g = graph(4)
    g.tctrl.zero_()
    candidates = ~torch.eye(4, dtype=torch.bool)
    assert tf.select_connectivity_probe(g, candidates, torch.ones(4, dtype=torch.bool), 0.5, 0.5)[0] == (0, 1)
    assert tf.select_connectivity_probe(g, candidates & False, torch.ones(4, dtype=torch.bool), 0.5, 0.5) == (None, -float('inf'))


def test_path_cache_and_all_input_invalidations():
    g = graph(5)
    tf.validated_paths(g, 0.5)
    original = g._validated_paths_cache
    tf.validated_paths(g, 0.5)
    assert g._validated_paths_cache is original
    # Protect cache from accidental caller modification.
    for tensor in tf.validated_paths(g, 0.5):
        tensor.zero_()
    mutations = [lambda: g.tctrl.data.fill_(2),
                 lambda: g.edge_confidence.data.zero_(),
                 lambda: g.edge_confidence.data.fill_(1),
                 lambda: g.control_attempts.data.fill_(10),
                 lambda: setattr(g, 'tctrl', torch.full((5, 5), 3.0))]
    for mutate in mutations:
        mutate()
        actual = tf.validated_paths(g, 0.5)
        fresh = SimpleNamespace(n_nodes=5, tctrl=g.tctrl.clone(), edge_confidence=g.edge_confidence.clone(),
                                control_attempts=g.control_attempts.clone())
        for x, y in zip(actual, tf.validated_paths(fresh, 0.5)):
            assert torch.equal(x, y)
    for threshold, reliability in [(0.0, 0.0), (2.0, 0.5), (0.5, 0.01)]:
        actual = tf.validated_paths(g, threshold, reliability)
        fresh = SimpleNamespace(n_nodes=5, tctrl=g.tctrl, edge_confidence=g.edge_confidence,
                                control_attempts=g.control_attempts)
        assert all(torch.equal(a, b) for a, b in zip(actual, tf.validated_paths(fresh, threshold, reliability)))
    g.tctrl = g.tctrl.double()
    assert tf.validated_paths(g, 0.0, 0.0)[0].dtype == torch.float64


def test_reachability_cache_invalidates_data_copy_and_reuses_unchanged_graph():
    g = SimpleNamespace()
    adjacency = torch.zeros((8, 8), dtype=torch.bool)
    with patch.object(tf, '_transitive_reachability', wraps=tf._transitive_reachability) as closure:
        tf._graph_connectivity_gains(g, adjacency)
        tf._graph_connectivity_gains(g, adjacency.clone())
        assert closure.call_count == 1
        adjacency.data[1, 2] = True
        actual = tf._graph_connectivity_gains(g, adjacency)
        assert closure.call_count == 2
        assert actual[0, 1] == 2


def test_caches_do_not_change_checkpoint_keys_and_load_refreshes():
    g = PolicyControllableGraph(4)
    keys = set(g.state_dict())
    tf.validated_paths(g, 0.5)
    tf._graph_connectivity_gains(g, tf.reliable_edges(g, 0.5))
    assert set(g.state_dict()) == keys
    replacement = PolicyControllableGraph(4)
    replacement.tctrl.fill_(1)
    replacement.edge_confidence.fill_(2)
    replacement.control_attempts.fill_(2)
    g.load_state_dict(replacement.state_dict())
    assert all(torch.equal(a, b) for a, b in zip(tf.validated_paths(g, 0.5), tf.validated_paths(replacement, 0.5)))
    assert torch.equal(tf._graph_connectivity_gains(g, tf.reliable_edges(g, 0.5)),
                       tf._graph_connectivity_gains(replacement, tf.reliable_edges(replacement, 0.5)))
