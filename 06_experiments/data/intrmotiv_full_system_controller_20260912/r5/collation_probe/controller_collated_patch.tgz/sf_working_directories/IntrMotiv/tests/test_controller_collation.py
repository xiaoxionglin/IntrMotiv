from dataclasses import replace
import numpy as np
import pytest
import torch
from sf_working_directories.IntrMotiv.tests.test_controller_transition import RewardModel,physical_rows
from sf_working_directories.IntrMotiv.dmlab.controller_transition import TransitionInput,make_histories


@pytest.mark.parametrize('write',[False,True])
def test_collation_preserves_unequal_histories_and_virtual_conditions(write):
    model=RewardModel(write).eval();rows,_=physical_rows(model)
    examples=[TransitionInput(tuple(rows[:2]),0),TransitionInput(tuple(rows),1)]
    examples.append(replace(examples[1],virtual_goal=2,remaining=3))
    original=[row.condition.copy() for row in rows]
    histories,contexts=make_histories(model,examples)
    for example,history,context in zip(examples,histories,contexts):
        assert history.decision_ids.tolist()==[row.index for row in example.rows]
        for key,value in history.observations.items():
            torch.testing.assert_close(value,torch.as_tensor(np.stack([row.observation[key] for row in example.rows])),rtol=0,atol=0)
        torch.testing.assert_close(context,torch.as_tensor(np.stack([row.context for row in example.rows])),rtol=0,atol=0)
        assert history.initial_context.count_nonzero()==0
        if example.virtual_goal is None:
            torch.testing.assert_close(history.conditions,torch.as_tensor(np.stack([row.condition for row in example.rows])),rtol=0,atol=0)
        else:
            assert torch.all(history.conditions[:,2]==1)
            assert history.conditions.sum()==len(example.rows)
    for row,before in zip(rows,original):np.testing.assert_array_equal(row.condition,before)
