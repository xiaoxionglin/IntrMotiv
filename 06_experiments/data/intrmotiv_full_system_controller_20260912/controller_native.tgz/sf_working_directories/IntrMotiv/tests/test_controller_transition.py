from types import SimpleNamespace
from dataclasses import replace
import numpy as np
import pytest
import torch
from torch import nn
from sf_working_directories.IntrMotiv.dmlab.custom_core import SimpleSequenceWithBypassCore
from sf_working_directories.IntrMotiv.dmlab.goal_conditioned_dg import GoalConditionedDGCore
from sf_working_directories.IntrMotiv.dmlab.custom_actor_critic import TargetFiLMDecoder,controller_core_view
from sf_working_directories.IntrMotiv.dmlab.controller_q import ControllerQHeads,continuing_double_q_target
from sf_working_directories.IntrMotiv.dmlab.controller_replay import PhysicalDecision
from sf_working_directories.IntrMotiv.dmlab.controller_transition import TransitionInput,transition_values,ReplayRejected
from sf_working_directories.IntrMotiv.dmlab.hrl_controllable_graph import HRLStateLayout


class RewardModel(nn.Module):
    def __init__(self,write):
        super().__init__()
        self.cfg=SimpleNamespace(Hippo_R=2,Hippo_L=3,Hippo_n_feature=3,hrl_controllable_graph=True,
            hrl_graph_memory='policy_buffer',hrl_target_timing='immediate',hrl_manager_mode='frontier_direct',
            dg_context_feedback='none',dg_orthogonal_recruitment=False,DG_BN_intercept=0.,
            reward_scale=.1,encoder_reward_method='encourage',hrl_worker_reward_mode='hit_distance',
            hrl_target_hit_reward=1.,hrl_distance_bonus_coeff=.1,controller_learning='ddqn')
        self.core=GoalConditionedDGCore(self.cfg,19) if write else SimpleSequenceWithBypassCore(self.cfg,16)
        self.scale=nn.Parameter(torch.ones(3));self.decoder=TargetFiLMDecoder(self.core,8)
        self.controller_q=ControllerQHeads(8,2,True);self.write=write
    def device_for_input_tensor(self,key):return torch.device('cpu')
    def type_for_input_tensor(self,key):return torch.float32
    def normalize_obs(self,obs):return obs
    def forward_head(self,obs):
        pre=obs['obs']*self.scale
        head=torch.cat((pre.relu(),torch.zeros(len(pre),13)),-1)
        return torch.cat((head,pre.detach()),-1) if self.write else head
    def forward_core(self,head,state):return self.core(head,state)
    def controller_hidden(self,out):
        view=self.core.worker_view(out) if self.write else controller_core_view(out,self.core.core_output_size,'stop')
        return self.decoder(view)


def physical_rows(model):
    state=torch.zeros(1,model.core.total_state_size);rows=[];states=[state]
    with torch.no_grad():
        for t,obs in enumerate(torch.eye(3)):
            out,state=model.forward_core(model.forward_head({'obs':obs[None]}),state)
            canonical=model.core.split_worker_state(state)[0] if model.write else state
            rows.append(PhysicalDecision((0,0),0,t,t,{'obs':obs.numpy()},0,
                out[0,model.core.target_condition_start:model.core.total_output_size].numpy(),
                canonical[0,model.core.base_state_size:].numpy(),0,0,False,False,4))
            states.append(state)
    return rows,states


@pytest.mark.parametrize('write',[False,True])
def test_original_reward_parity_and_virtual_goal_has_positive_learning_signal(write):
    from sf_working_directories.IntrMotiv.dmlab.custom_learner import DistanceLearnerReward
    model=RewardModel(write).eval();rows,states=physical_rows(model)
    example=TransitionInput(tuple(rows[:2]),0)
    main=transition_values(model,example)
    adapter=object.__new__(DistanceLearnerReward);adapter.cfg=model.cfg;adapter.actor_critic=model
    buff={'rnn_states':torch.stack([s[0] for s in states[:2]])[None],
        'rewards':torch.zeros(1,1),'dones':torch.zeros(1,1,dtype=torch.bool)}
    adapter._calculate_reward_components(buff,{'new_rnn_states':states[2]})
    torch.testing.assert_close(main['reward'],buff['rewards'].reshape(()))
    before={k:v.clone() for k,v in model.state_dict().items()}
    virtual=transition_values(model,replace(example,virtual_goal=1,remaining=3))
    assert virtual['reward']>0 and virtual['done']
    virtual['q'][0,0].backward()
    assert model.controller_q.auxiliary.weight.grad.abs().sum()>0
    assert model.controller_q.main.weight.grad is None
    for k,v in model.state_dict().items():torch.testing.assert_close(v,before[k])


def test_changed_recognition_rejected_and_physical_truncation_stops_main():
    model=RewardModel(True).eval();rows,_=physical_rows(model)
    example=TransitionInput(tuple(rows[:2]),0)
    ended=replace(rows[0],truncated=True)
    result=transition_values(model,replace(example,rows=(ended,rows[1])))
    assert result['done']
    with torch.no_grad():model.scale[0]=-1
    with pytest.raises(ReplayRejected,match='recognition_changed'):transition_values(model,example)


def test_main_target_continues_after_an_actual_goal_switch():
    # Done is physical, regardless of target-hit/manager goal-switch events.
    reward=torch.tensor([1.]);online=torch.tensor([[2.,5.]]);target=torch.tensor([[9.,7.]])
    result=continuing_double_q_target(reward,torch.tensor([False]),online,target,.9)
    torch.testing.assert_close(result,torch.tensor([7.3]))
