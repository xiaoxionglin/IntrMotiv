import numpy as np
from sf_working_directories.IntrMotiv.dmlab.controller_schedule import UpdateClock,replay_rngs
from sf_working_directories.IntrMotiv.dmlab.controller_q import exploration_epsilon
from types import SimpleNamespace


def test_main_budget_identical_with_auxiliary_and_checkpoint_resume():
    clocks=[UpdateClock(),UpdateClock()]
    for accepted in (16000,16384,20480,24576):
        for i,c in enumerate(clocks):
            for _ in range(c.due(accepted)):c.finish(256,256*i)
    assert clocks[0].completed==clocks[1].completed==128
    assert clocks[0].main_positions==clocks[1].main_positions==32768
    assert clocks[1].auxiliary_positions==32768
    assert clocks[0].target_at==clocks[1].target_at==100
    resumed=UpdateClock();resumed.load_state_dict(clocks[1].state_dict())
    assert resumed.due(28672)==64
    assert resumed.state_dict()==clocks[1].state_dict()


def test_auxiliary_rng_does_not_perturb_main_selection():
    a,ha=replay_rngs(99);b,hb=replay_rngs(99)
    for _ in range(5):
        ha.integers(1000,size=256)
        hb.integers(1000,size=0)
        np.testing.assert_array_equal(a.integers(1000,size=256),b.integers(1000,size=256))


def test_warmup_and_annealing():
    cfg=SimpleNamespace(controller_learning_starts=16384,controller_epsilon_decay_decisions=250000,controller_epsilon=.1)
    assert exploration_epsilon(0,cfg)==exploration_epsilon(16384,cfg)==1
    assert abs(exploration_epsilon(141384,cfg)-.55)<1e-8
    assert abs(exploration_epsilon(999999,cfg)-.1)<1e-8
