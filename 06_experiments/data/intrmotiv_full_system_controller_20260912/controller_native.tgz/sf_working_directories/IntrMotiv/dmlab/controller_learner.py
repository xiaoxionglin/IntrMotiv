"""Original fresh DG learner followed by separately budgeted controller replay."""
import copy
from dataclasses import replace
import random
import time
import numpy as np
import torch
import torch.nn.functional as F
from sample_factory.algo.learning.learner import model_initialization_data
from sample_factory.model.actor_critic import create_actor_critic
from sample_factory.utils.attr_dict import AttrDict
from sample_factory.algo.utils.misc import TRAIN_STATS,LEARNER_ENV_STEPS,POLICY_ID_KEY
from .custom_learner import DistanceLearnerReward
from .controller_snapshot import ControllerSnapshot,differentiable_replay,evaluate_replay
from .controller_replay import PhysicalReplay,PhysicalDecision
from .controller_schedule import UpdateClock,replay_rngs
from .controller_transition import TransitionInput,ReplayRejected,transition_values
from .controller_transport import cached_observation,IDENTITY_KEY
from .controller_history import ControllerHistory,reconstruct_controller_history
from .controller_q import continuing_double_q_target
from .hrl_controllable_graph import HRLStateLayout,current_dg_from_activity


class ControllerLearner(DistanceLearnerReward):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        c=self.cfg
        self.replay=PhysicalReplay(c.controller_replay_capacity,c.seed)
        self.replay.rng,self.her_rng=replay_rngs(c.seed)
        self.clock=UpdateClock(c.controller_learning_starts,c.controller_decisions_per_update,c.controller_target_updates)
        self.controller_version=0
        self.controller_stats={}
        self.fresh_dg_steps=self.fresh_graph_batches=0
        self._restore_controller=None
        self.publication=0
        self._milestone_previous=None

    def init(self):
        super().init()
        def factory():
            model=create_actor_critic(self.cfg,self.env_info.obs_space,self.env_info.action_space)
            model.model_to_device(self.device)
            return model
        self.online_snapshot=ControllerSnapshot(factory,self.actor_critic,self.controller_version)
        self.target_snapshot=ControllerSnapshot(factory,self.actor_critic,self.controller_version)
        self.published=ControllerSnapshot(factory,self.actor_critic,self.controller_version).model
        self.published._apply(lambda t:t.share_memory_() if not t.is_cuda else t)
        if self._restore_controller is not None:
            c=self._restore_controller
            self.replay.load_state_dict(c['replay']);self.clock.load_state_dict(c['clock'])
            self.her_rng.bit_generator.state=c['her_rng']
            self.controller_version=c['version'];self.publication=c['publication']
            self.target_snapshot.model.load_state_dict(c['target'])
            self.target_snapshot.version=c['target_version']
            self.online_snapshot.version=self.controller_version
            self.fresh_dg_steps=c['fresh_dg_steps'];self.fresh_graph_batches=c['fresh_graph_batches']
            torch.set_rng_state(c['torch_rng'].cpu());np.random.set_state(c['numpy_rng']);random.setstate(c['python_rng'])
            if torch.cuda.is_available() and c['cuda_rng']:torch.cuda.set_rng_state_all(c['cuda_rng'])
        # Actors only see this copy. The parent's minibatch optimizer/publication
        # writes affect private learner storage until the transaction finishes.
        self._published_versions=self.policy_versions_tensor
        self.policy_versions_tensor=self.policy_versions_tensor.clone()
        self.param_server.init(self.published,self.publication,self.device)
        if getattr(self.cfg,'save_initial_checkpoint',False) and self.env_steps==0:
            self._save_impl('initial','',1)
        return model_initialization_data(self.cfg,self.policy_id,self.published,self.publication,self.device)

    def _save_impl(self,*args,**kwargs):
        if not hasattr(self,'target_snapshot'):return False
        return super()._save_impl(*args,**kwargs)

    def _save_crossed_frame_targets(self,previous_frames):
        # The parent invokes this before replay. Save only after publication.
        self._milestone_previous=previous_frames

    def _load_state(self,checkpoint_dict,load_progress=True):
        super()._load_state(checkpoint_dict,load_progress)
        if load_progress:
            if 'controller' not in checkpoint_dict:raise RuntimeError('Controller resume requires complete replay/target state')
            self._restore_controller=checkpoint_dict['controller']

    def _get_checkpoint_dict(self):
        checkpoint=super()._get_checkpoint_dict()
        if hasattr(self,'target_snapshot'):
            checkpoint['controller']=dict(replay=self.replay.state_dict(),clock=self.clock.state_dict(),
                her_rng=copy.deepcopy(self.her_rng.bit_generator.state),version=self.controller_version,publication=self.publication,
                target=self.target_snapshot.model.state_dict(),target_version=self.target_snapshot.version,
                fresh_dg_steps=self.fresh_dg_steps,fresh_graph_batches=self.fresh_graph_batches,
                torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
                numpy_rng=np.random.get_state(),python_rng=random.getstate())
        return checkpoint

    def _prepare_recurrent_replay_head(self,head_outputs,mb):
        if self.cfg.controller_learning=='ddqn' and getattr(self.cfg,'dg_goal_input','none')=='write':
            return torch.cat((head_outputs,mb.controller_condition),-1)
        return super()._prepare_recurrent_replay_head(head_outputs,mb)

    def _override_core_outputs_for_replay(self,core_outputs,mb):
        if self.cfg.controller_learning=='ddqn':
            out=core_outputs.clone();core=self.actor_critic.core
            out[:,core.target_condition_start:core.total_output_size]=mb.controller_condition
            return out
        return super()._override_core_outputs_for_replay(core_outputs,mb)

    def _update_policy_graph_from_rollout(self,*args,**kwargs):
        result=super()._update_policy_graph_from_rollout(*args,**kwargs)
        self.fresh_graph_batches+=1
        return result

    def _calculate_losses(self,mb,num_invalids,iterative_phase,**kwargs):
        if self.cfg.controller_learning!='ddqn':return super()._calculate_losses(mb,num_invalids,iterative_phase,**kwargs)
        additional=AttrDict();valids=mb.valids;recurrence=self.cfg.recurrence
        outputs=self._forward_fresh_dg(mb,recurrence,valids,iterative_phase,additional)
        distance,masked,_=self._record_distance_matrix(outputs.core_outputs.detach(),
            minibatch_size=outputs.minibatch_size,masked_matrix=True,return_progression=True)
        additional['Distance Matrix']=distance;additional['Distance Matrix Masked']=masked
        encoder_loss=self._calculate_fresh_encoder_loss(outputs,mb,valids,num_invalids,recurrence,additional)
        zero=encoder_loss.new_zeros(())
        # Retain the parent's dashboard contract without computing PPO losses.
        for name in ('behavior_replay_mismatch','ca3_predictor_loss','ca3_predictor_hit_accuracy',
            'ca3_predictor_time_mae','ca3_predictor_positive_fraction','empirical_her_loss',
            'empirical_her_policy_loss','empirical_her_value_loss','empirical_her_ratio',
            'empirical_her_clip_fraction','empirical_her_valid_fraction',
            'goal_condition_target_valid_fraction','goal_condition_action_sensitivity',
            'goal_condition_action_probability_tv','goal_condition_value_span'):
            additional[name]=zero
        for mode in ('goal','free'):
            for name in ('policy_loss','value_loss','entropy_loss'):additional[f'{mode}_{name}']=zero
        summaries=dict(ratio=torch.ones_like(mb.advantages),clip_ratio_low=1.,clip_ratio_high=1.,
            values=outputs.result['values'],adv=mb.advantages,adv_std=zero,adv_mean=zero,additional_stats=additional)
        self.fresh_dg_steps+=1
        return self.actor_critic.action_distribution(),zero,zero,zero[None],zero,zero,zero,encoder_loss,summaries

    def _ingest(self,batch):
        # Shared SF buffers may be reused immediately after this transaction.
        cpu=lambda x:x.detach().cpu().numpy().copy()
        n,t=batch['actions'].shape[:2]
        layout=HRLStateLayout(self.cfg.Hippo_n_feature)
        for i in range(n):
            for j in range(t):
                stream,episode,index,serial=map(int,cpu(batch['obs'][IDENTITY_KEY][i,j]))
                obs={k:cpu(v[i,j]) for k,v in batch['obs'].items() if k!=IDENTITY_KEY}
                if self.cfg.controller_cache_visual:
                    obs=cached_observation(obs,cpu(batch['controller_visual'][i,j]))
                done=bool(batch['dones'][i,j]);valid=bool(batch['controller_final_valid'][i,j])
                successor=None
                if done and valid:
                    successor={k:cpu(v[i,j]) for k,v in batch['controller_final_obs'].items() if k!=IDENTITY_KEY}
                    # Terminal RGB is retained. It is converted once when sampled.
                context=cpu(batch['controller_context'][i,j])
                self.replay.receive(PhysicalDecision((self.replay.session,stream),episode,index,serial,obs,
                    int(batch['actions'][i,j].item()),cpu(batch['controller_condition'][i,j]),context,
                    int(batch['policy_version'][i,j]),int(context[layout.persistent_start]),
                    bool(batch['controller_terminated'][i,j]),bool(batch['time_outs'][i,j]),
                    int(batch['controller_frames'][i,j]),successor,valid))
        self.controller_stats['actor_memory_rebuilds']=float(batch['controller_memory_stats'][...,0].max())
        self.controller_stats['actor_memory_rebuild_seconds']=float(batch['controller_memory_stats'][...,2].max())
        self.controller_stats['actor_memory_version_failures']=float(batch['controller_memory_stats'][...,1].max())

    def _example(self,key):
        prefix,suffix=self.replay.sequence(key,self.actor_critic.core.expanded_length,2)
        row=suffix[0]
        generation=int(self.actor_critic.core.policy_graph.representation_generation.item())
        if any(r.generation!=generation for r in prefix+suffix):raise ReplayRejected('stale_structural_generation')
        if row.terminated or row.truncated:
            if not row.successor_valid:raise ReplayRejected('uncertified_terminal_observation')
            obs=row.successor
            if self.cfg.controller_cache_visual:
                from sample_factory.algo.utils.rl_utils import prepare_and_normalize_obs
                raw={k:torch.as_tensor(v,device=self.device)[None] for k,v in obs.items()}
                with torch.no_grad():
                    norm=prepare_and_normalize_obs(self.online_snapshot.model,raw)
                    self.online_snapshot.model.forward_head(norm)
                    visual=self.online_snapshot.model.encoder._controller_visual[0].cpu().numpy()
                obs=cached_observation(obs,visual)
            successor=replace(row,index=row.index+1,serial=row.serial+1,observation=obs)
        elif len(suffix)<2:raise ReplayRejected('missing_successor_context')
        else:successor=suffix[1]
        return TransitionInput(tuple(prefix+[row,successor]),len(prefix))

    def _evaluate_pair(self,example):
        online=differentiable_replay(self.online_snapshot,self.actor_critic,transition_values,example,
            source_version=self.controller_version)
        target=evaluate_replay(self.target_snapshot,transition_values,example)
        if not torch.equal(online['signature'],target['signature']):raise ReplayRejected('target_event_incompatible')
        # Virtual recognition is goal-local; both snapshots must agree on success.
        if online['done']!=target['done']:raise ReplayRejected('target_boundary_incompatible')
        row=example.rows[example.burn_in]
        desired=continuing_double_q_target(online['reward'][None],torch.tensor([online['done']],device=self.device),
            online['q'][1:2],target['q'][1:2],self.cfg.gamma)
        return F.smooth_l1_loss(online['q'][0,row.action],desired[0],reduction='none'),online

    def _her_example(self,example):
        row=example.rows[example.burn_in];layout=HRLStateLayout(self.cfg.Hippo_n_feature)
        budget=int(row.context[layout.countdown])
        if budget<1:raise ReplayRejected('her_budget_expired')
        _,future=self.replay.sequence(row.key,0,budget+1)
        if len(future)<2:raise ReplayRejected('her_no_future_achievement')
        # Use the same canonical reconstruction as controller evaluation. Future
        # candidates are real observations, never virtual graph entries.
        prefix=list(example.rows[:example.burn_in]);rows=prefix+future
        device=self.device;core=self.actor_critic.core
        observations={k:torch.as_tensor(np.stack([r.observation[k] for r in rows]),device=device) for k in row.observation}
        h=ControllerHistory(observations,torch.tensor([r.index for r in rows],device=device),
            torch.zeros(1,core.total_state_size,device=device),
            torch.as_tensor(np.stack([r.condition for r in rows]),device=device),rows[0].index==0,len(prefix))
        result=evaluate_replay(self.online_snapshot,reconstruct_controller_history,h)
        target_result=evaluate_replay(self.target_snapshot,reconstruct_controller_history,h)
        target_dg=target_result['core_outputs'][:,:core.core_output_size].reshape(-1,core.Hippo_n_feature,core.expanded_length)[:,:,0]
        target_ids,target_active,target_count=current_dg_from_activity(target_dg)
        dg=result['core_outputs'][:,:core.core_output_size].reshape(-1,core.Hippo_n_feature,core.expanded_length)[:,:,0]
        ids,active,count=current_dg_from_activity(dg)
        eligible=[int(ids[i]) for i in range(1,len(future)) if bool(active[i]) and int(count[i])==1 and dg[0,ids[i]]<=0
            and bool(target_active[i]) and int(target_count[i])==1 and target_ids[i]==ids[i] and target_dg[0,ids[i]]<=0]
        if not eligible:raise ReplayRejected('her_no_future_achievement')
        goal=eligible[int(self.her_rng.integers(len(eligible)))]
        return replace(example,virtual_goal=goal,remaining=budget)

    def _controller_updates(self):
        main_seconds=her_seconds=0.
        for _ in range(self.clock.due(self.replay.accepted)):
            # Refresh online buffers after each optimizer transaction, target only
            # on its independent completed-main-update clock.
            self.online_snapshot.refresh(self.actor_critic,self.controller_version+1)
            self.controller_version+=1
            losses=[];examples=[];qs=[];started=time.perf_counter()
            # Bounded work on a depleted/incompatible replay: retain update debt.
            for key in self.replay.candidates(self.cfg.controller_td_positions*4):
                try:
                    example=self._example(key);loss,result=self._evaluate_pair(example)
                except (ReplayRejected,ValueError) as exc:
                    if type(exc) is ValueError and str(exc) not in ('missing_history','cross_episode'):raise
                    self.replay.reject(str(exc));continue
                losses.append(loss);examples.append(example);qs.append(result['q'].detach())
                if len(losses)==self.cfg.controller_td_positions:break
            if len(losses)<self.cfg.controller_td_positions:
                self.replay.reject('insufficient_main_batch');break
            main_loss=torch.stack(losses).mean();main_seconds+=time.perf_counter()-started
            aux=[];started=time.perf_counter()
            if self.cfg.controller_her:
                for _ in range(self.cfg.controller_her_positions):
                    example=examples[int(self.her_rng.integers(len(examples)))]
                    try:loss,_=self._evaluate_pair(self._her_example(example))
                    except ReplayRejected as exc:self.replay.reject(str(exc));continue
                    aux.append(loss)
            aux_loss=torch.stack(aux).mean() if aux else main_loss.new_zeros(())
            her_seconds+=time.perf_counter()-started
            self.optimizer.zero_grad(set_to_none=True)
            (main_loss+self.cfg.controller_her_loss_coeff*aux_loss).backward()
            if self.cfg.max_grad_norm>0:torch.nn.utils.clip_grad_norm_(self.actor_critic.parameters(),self.cfg.max_grad_norm)
            self._apply_lr(self.curr_lr)
            self.optimizer.step()
            refresh=self.clock.finish(len(losses),len(aux))
            if refresh:self.target_snapshot.refresh(self.actor_critic,self.controller_version)
            all_q=torch.cat(qs)
            self.controller_stats.update(main_loss=float(main_loss.detach()),auxiliary_loss=float(aux_loss.detach()),
                q_mean=float(all_q.mean()),q_abs_max=float(all_q.abs().max()))
        self.controller_stats.update(main_compute_seconds=main_seconds,her_compute_seconds=her_seconds,
            her_overhead_ratio=her_seconds/max(main_seconds,1e-9))

    def train(self,batch):
        started=time.perf_counter();self._ingest(batch)
        before=self.env_steps
        stats=super().train(batch)
        self.env_steps=before+(int(batch['controller_frames'].sum()) if self.cfg.summaries_use_frameskip else batch['actions'].numel())
        self._controller_updates()
        with torch.no_grad(),self.param_server.policy_lock:
            self.actor_critic.controller_q.environment_decisions.fill_(self.replay.accepted)
            self.publication+=1
            self.actor_critic.controller_q.publication_version.fill_(self.publication)
            self.actor_critic.controller_q.fresh_version.fill_(self.train_step)
            self.published.load_state_dict(self.actor_critic.state_dict())
            if self.device.type=='cuda':torch.cuda.synchronize(self.device)
            self._published_versions[self.policy_id]=self.publication
        super()._save_crossed_frame_targets(before)
        stats=stats or {POLICY_ID_KEY:self.policy_id}
        stats[LEARNER_ENV_STEPS]=self.env_steps
        self.controller_stats.update(physical_interactions=self.replay.received,physical_frames=self.replay.physical_frames,
            accepted_replay_decisions=self.replay.accepted,main_updates=self.clock.completed,
            main_td_positions=self.clock.main_positions,auxiliary_td_positions=self.clock.auxiliary_positions,
            target_age=self.clock.completed-self.clock.target_at,update_debt=self.clock.due(self.replay.accepted),
            fresh_dg_steps=self.fresh_dg_steps,fresh_graph_batches=self.fresh_graph_batches,
            transaction_seconds=time.perf_counter()-started)
        self.controller_stats.update({f'rejected/{k}':v for k,v in self.replay.rejected.items()})
        stats.setdefault(TRAIN_STATS,{}).update({f'controller/{k}':v for k,v in self.controller_stats.items()})
        return stats
