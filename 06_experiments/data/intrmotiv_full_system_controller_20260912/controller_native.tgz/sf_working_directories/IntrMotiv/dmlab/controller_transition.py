"""Snapshot-consistent worker values and original reward/event reconstruction."""
from dataclasses import dataclass
import numpy as np
import torch
from .controller_history import ControllerHistory,reconstruct_controller_history,reconstruct_controller_histories
from .goal_conditioned_dg import GoalConditionedDGCore
from .hrl_controllable_graph import HRLStateLayout,current_dg_from_activity,hrl_option_state_size
from .topological_frontier import TopologicalStateLayout,MODE_NAVIGATE


class ReplayRejected(ValueError):pass


@dataclass(frozen=True)
class TransitionInput:
    rows: tuple
    burn_in: int
    virtual_goal: int | None = None
    remaining: int | None = None


def assemble_state(core, output, context):
    canonical=torch.cat((output[:core.base_state_size],context),-1).unsqueeze(0)
    if isinstance(core,GoalConditionedDGCore):
        canonical=core.join_worker_state(canonical,output[core.total_output_size:].unsqueeze(0))
    return canonical


def event_signature(context,n):
    layout=HRLStateLayout(n)
    return torch.stack((context[...,layout.active_dg],context[...,layout.multi_activation],
        context[...,layout.target_hit],context[...,layout.option_expired],
        context[...,layout.completion_elapsed].sign()),-1)


def make_history(model,example):
    core=model.core;device=next(model.parameters()).device
    rows=example.rows;b=example.burn_in
    obs={k:torch.as_tensor(np.stack([r.observation[k] for r in rows]),device=device)
         for k in rows[0].observation}
    conditions=torch.as_tensor(np.stack([r.condition for r in rows]),device=device)
    if example.virtual_goal is not None:
        conditions=torch.zeros_like(conditions);conditions[:,example.virtual_goal]=1
    return ControllerHistory(obs,torch.tensor([r.index for r in rows],device=device),
        torch.zeros(1,core.total_state_size,device=device),conditions,rows[0].index==0,b)


def transition_values_batch(model,examples):
    histories=[make_history(model,example) for example in examples]
    reconstructed=reconstruct_controller_histories(model,histories)
    results=[]
    for example,history in zip(examples,reconstructed):
        try:results.append(transition_values(model,example,history))
        except ReplayRejected as exc:results.append(str(exc))
    return results


def transition_values(model,example,reconstructed=None):
    """Only private snapshots call this; real manager/graph state is never updated."""
    from .custom_learner import DistanceLearnerReward
    core=model.core;device=next(model.parameters()).device
    rows=example.rows;b=example.burn_in;n=core.Hippo_n_feature
    if len(rows)!=b+2:raise ValueError('Expected prefix, current and physical successor')
    generation=int(core.policy_graph.representation_generation.item())
    if any(row.generation!=generation for row in rows):raise ReplayRejected('snapshot_structural_generation_incompatible')
    if reconstructed is None:
        reconstructed=reconstruct_controller_history(model,make_history(model,example))
    contexts=torch.as_tensor(np.stack([r.context for r in rows]),device=device)
    outputs=reconstructed['all_core_outputs']
    current,next_output=outputs[b:b+2]
    canonical_dg=current[:core.core_output_size].reshape(n,core.expanded_length)[:,0]
    next_dg=next_output[:core.core_output_size].reshape(n,core.expanded_length)[:,0]
    layout=HRLStateLayout(n)
    # Recognition must agree with the context on which the actual manager acted.
    with torch.no_grad():
        active,_,count=current_dg_from_activity(canonical_dg[None])
        if example.virtual_goal is None:
            prefix_dg=outputs[:b+1,:core.core_output_size].reshape(-1,n,core.expanded_length)[:,:,0]
            ids,_,counts=current_dg_from_activity(prefix_dg)
            if not torch.equal((ids+1).to(contexts),contexts[:b+1,layout.active_dg]) or not torch.equal(counts>1,contexts[:b+1,layout.multi_activation].bool()):
                raise ReplayRejected('history_recognition_changed')
        if active.item()+1!=contexts[b,layout.active_dg].item() or bool(count.item()>1)!=bool(contexts[b,layout.multi_activation].item()):
            raise ReplayRejected('current_recognition_changed')
        context=contexts[b].clone()
        if example.virtual_goal is not None:
            goal=example.virtual_goal
            if canonical_dg[goal]>0:raise ReplayRejected('her_start_already_achieved')
            if example.remaining is None or example.remaining<1:raise ReplayRejected('her_budget_expired')
            context[layout.target]=goal+1
            context[layout.countdown]=example.remaining
            context[layout.selected_deadline]=example.remaining
            context[layout.age]=0
            topo=TopologicalStateLayout(n);offset=hrl_option_state_size(n)
            context[offset+topo.mode]=MODE_NAVIGATE
            context[offset+topo.final_goal]=goal+1
            context[offset+topo.pending_source]=0
            context[offset+topo.pending_destination]=0
        state=assemble_state(core,current.detach(),context)
        hrl=core._split_state(state)[1].clone()
        next_hrl,_=core._update_hrl(hrl,next_dg.detach()[None],current[:core.core_output_size].detach()[None])
        # Descriptor is an actual action-time label. It is not a new graph choice.
        next_context=torch.cat((next_hrl[0],contexts[b+1,-core.behavior_goal_state_size:]),-1)
        signature=event_signature(next_context,n)
        physical_done=rows[b].terminated or rows[b].truncated
        if example.virtual_goal is None and not physical_done:
            if not torch.equal(signature,event_signature(contexts[b+1],n)):
                raise ReplayRejected('successor_events_changed')
        previous=(assemble_state(core,outputs[b-1].detach(),contexts[b-1]) if b else torch.zeros_like(state))
        successor=assemble_state(core,next_output.detach(),next_context)
        # Invoke the parent's exact temporal and control-reward functions, without
        # credit assignment, DG losses, normalizer updates, or graph accumulation.
        adapter=object.__new__(DistanceLearnerReward)
        adapter.cfg=model.cfg;adapter.actor_critic=model
        buff={'rnn_states':torch.stack((previous[0],state[0]))[None],
            'rewards':torch.zeros(1,1,device=device),'dones':torch.tensor([[physical_done]],device=device)}
        adapter._calculate_reward_components(buff,{'new_rnn_states':successor})
        reward=buff['rewards'].reshape(())
        hit=next_context[layout.target_hit]>0
        ended=physical_done or (example.virtual_goal is not None and (bool(hit) or example.remaining<=1))
    hidden=reconstructed['hidden']
    if getattr(model.cfg,'controller_learning','ddqn')=='shadow':hidden=hidden.detach()
    if example.virtual_goal is None:
        q=model.controller_q(hidden)
    else:
        remaining=torch.tensor([example.remaining, max(0,example.remaining-1)],device=device)
        q=model.controller_q.hindsight(hidden,remaining,float(model.cfg.Hippo_L))
    return {'q':q,'reward':reward,'signature':signature,'done':ended,
            'canonical':canonical_dg.detach(),'next_canonical':next_dg.detach()}
