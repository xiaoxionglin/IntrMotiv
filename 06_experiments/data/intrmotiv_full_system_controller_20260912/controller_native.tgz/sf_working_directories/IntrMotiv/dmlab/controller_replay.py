"""Owned physical replay, without frozen-DG representations or virtual graph rows."""
from collections import OrderedDict
from dataclasses import dataclass
import copy
import numpy as np
from hpc_runs.intrmotiv_offpolicy.sf_transport import OrderedIngress


@dataclass(frozen=True)
class PhysicalDecision:
    stream: tuple
    episode: int
    index: int
    serial: int
    observation: dict
    action: int
    condition: np.ndarray
    context: np.ndarray
    publication: int
    generation: int
    terminated: bool
    truncated: bool
    physical_frames: int
    successor: dict | None = None
    successor_valid: bool = False
    real_reward: float | None = None
    real_events: dict | None = None

    @property
    def key(self):return self.stream,self.episode,self.index


class PhysicalReplay:
    def __init__(self,capacity,seed):
        self.capacity=int(capacity)
        self.rows=OrderedDict()
        self.rng=np.random.default_rng(seed)
        self.ingress=OrderedIngress(max_pending=capacity)
        self.received=self.accepted=self.physical_frames=0
        self.session=0
        self.rejected={}

    def receive(self,row):
        # Ingress validation precedes accounting: duplicates are not interactions.
        owned=copy.deepcopy(row)
        self.ingress.add(row.stream,row.serial,owned)
        self.received+=1
        self.physical_frames+=row.physical_frames
        for ready in self.ingress.drain():
            if ready.key in self.rows:raise ValueError('Duplicate physical replay row')
            self.rows[ready.key]=ready
            self.accepted+=1
            while len(self.rows)>self.capacity:self.rows.popitem(last=False)

    def sequence(self,key,washout,future=1):
        row=self.rows[key]
        start=max(0,row.index-washout)
        prefix=[]
        for index in range(start,row.index+1):
            item=self.rows.get((row.stream,row.episode,index))
            if item is None:raise ValueError('missing_history')
            if index<row.index and (item.terminated or item.truncated):raise ValueError('cross_episode')
            prefix.append(item)
        suffix=[]
        for index in range(row.index,row.index+future):
            item=self.rows.get((row.stream,row.episode,index))
            if item is None:break
            suffix.append(item)
            if item.terminated or item.truncated:break
        return prefix[:-1],suffix

    def reject(self,reason):self.rejected[reason]=self.rejected.get(reason,0)+1

    def candidates(self,count):
        keys=list(self.rows)
        if not keys:return []
        indices=self.rng.integers(0,len(keys),size=count)
        return [keys[int(i)] for i in indices]

    def state_dict(self):
        return copy.deepcopy(dict(rows=self.rows,capacity=self.capacity,rng=self.rng.bit_generator.state,
            received=self.received,accepted=self.accepted,physical_frames=self.physical_frames,
            session=self.session,rejected=self.rejected,pending=self.ingress.pending))

    def load_state_dict(self,state):
        self.rows=copy.deepcopy(state['rows']);self.capacity=state['capacity']
        self.rng.bit_generator.state=state['rng']
        for key in ('received','accepted','physical_frames','rejected'):setattr(self,key,copy.deepcopy(state[key]))
        # DMLab itself is not restored. New actors start genuinely new episodes.
        self.session=int(state['session'])+1
        self.ingress=OrderedIngress(max_pending=self.capacity)
        if state['pending']:self.rejected['restart_pending_tail']=state['pending']
