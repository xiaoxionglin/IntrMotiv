"""Finite-history reconstruction through the original simple IntrMotiv core.

This operation runs on a private controller snapshot. It does not train the DG
auxiliary, publish actor weights, or treat replay as new manager graph evidence.
The ingress layer must supply one contiguous physical episode per call.
"""
from dataclasses import dataclass
from sample_factory.algo.utils.rl_utils import prepare_and_normalize_obs
import torch
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from sf_working_directories.IntrMotiv.dmlab.custom_core import SimpleSequenceWithBypassCore
from sf_working_directories.IntrMotiv.dmlab.goal_conditioned_dg import GoalConditionedDGCore


@dataclass(frozen=True)
class ControllerHistory:
    observations: dict
    decision_ids: torch.Tensor
    initial_context: torch.Tensor
    # The complete action-time condition in original core output order:
    # target, followed by any enabled geometry/mode fields.
    conditions: torch.Tensor
    episode_start: bool
    burn_in: int


def reconstruct_controller_history(model, history: ControllerHistory, *, memory_only=False):
    """Rebuild canonical/worker traces; return original decoder features.

    The action-time manager command is exogenous replay context. Historical
    decisions are not re-planned with today's graph. HER supplies its virtual
    command over the whole history, including worker writes before TD positions.
    Caller constructs online and target histories using their own snapshots.

    A non-reset prefix is only accepted for the actual finite simple core.
    Context feedback/recruitment require a separate, validated state contract.
    No actor memory is cleared by this function.
    """
    core = model.core
    if type(core) not in (SimpleSequenceWithBypassCore, GoalConditionedDGCore):
        raise ValueError('Finite replay washout is not established for this core')
    if core.context_feedback is not None or core.graph_recruitment or core.context_action_history_size:
        raise ValueError('Contextual/recruitment history needs its own reconstruction contract')
    if model.training:
        raise ValueError('Reconstruction requires an immutable evaluation snapshot')
    steps = history.decision_ids.numel()
    if history.decision_ids.ndim != 1 or steps < 1:
        raise ValueError('Expected a nonempty physical history')
    if not torch.all(history.decision_ids[1:] == history.decision_ids[:-1] + 1):
        raise ValueError('Replay history has a physical decision gap')
    if not 0 <= history.burn_in < steps:
        raise ValueError('Replay must retain TD positions after burn-in')
    if not history.episode_start and (steps if memory_only else history.burn_in) < core.expanded_length:
        raise ValueError('Incomplete finite washout prefix')
    condition_width = core.total_output_size - core.target_condition_start
    if history.conditions.shape != (steps, condition_width):
        raise ValueError('Incomplete action-time worker condition')
    if history.initial_context.shape != (1, core.total_state_size):
        raise ValueError('Invalid initial context layout')
    if any(value.shape[0] != steps for value in history.observations.values()):
        raise ValueError('Observation/history length mismatch')

    state = history.initial_context.detach().clone()
    if isinstance(core, GoalConditionedDGCore):
        canonical, worker = core.split_worker_state(state)
        canonical = canonical.clone()
        canonical[:, :core.core_output_size] = 0
        state = core.join_worker_state(canonical, torch.zeros_like(worker))
    else:
        state[:, :core.core_output_size] = 0
    # Original preprocessing and all trainable encoder/bypass modules run again.
    normalized = prepare_and_normalize_obs(model, dict(history.observations))
    head = model.forward_head(normalized)
    if isinstance(core, GoalConditionedDGCore):
        head = torch.cat((head, history.conditions[:, :core.Hippo_n_feature].to(head)), -1)
    # One packed sequence preserves the original goal-write BPTT path; calling
    # single-step core repeatedly would detach its worker memory at every step.
    packed = pack_padded_sequence(head.unsqueeze(1), [steps], enforce_sorted=False)
    packed_output, final_state = model.forward_core(packed, state)
    padded, _ = pad_packed_sequence(packed_output)
    output = padded[:, 0].clone()
    output[:, core.target_condition_start:core.total_output_size] = history.conditions.to(output)
    if memory_only:
        return {'reconstructed_state': final_state}
    hidden = model.controller_hidden(output)
    return {
        'hidden': hidden[history.burn_in:],
        'core_outputs': output[history.burn_in:],
        'all_core_outputs': output,
        'head_outputs': head[history.burn_in:],
        'decision_ids': history.decision_ids[history.burn_in:],
    }
