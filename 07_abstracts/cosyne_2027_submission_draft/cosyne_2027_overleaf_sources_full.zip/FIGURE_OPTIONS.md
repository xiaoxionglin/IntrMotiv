# Figure options for the COSYNE draft

The PDFs in `figures/` are used by `main.tex`. Each has an SVG source
beside it. Additional options are in `figures/candidates/`, organized
by the source analysis folder. Every candidate PDF has a matching SVG;
the PNG-only files are place-field, graph, and trajectory examples.
Change an `\includegraphics` path in `main.tex` to try an option.
Candidates include exploratory and historical plots; check the linked
analysis before making a scientific claim from a replacement panel.

## Current figure assets

- `figures/architecture.pdf`
- `figures/behavior_expression_fresh.pdf`
- `figures/c01_peak_density.pdf`
- `figures/encoder_credit_deltas.pdf`
- `figures/encoder_paired_decoder_1.pdf`
- `figures/online_spatial_course.pdf`
- `figures/results_sections.pdf`
- `figures/worker_coverage.pdf`

## Compact Figure 2 layout trial

- `figures/Figure2_tetris.pdf`
- `figures/Figure2_tetris.svg`
- `figures/Figure2_tetris_sidebar.pdf`
- `figures/Figure2_tetris_sidebar.svg`
- `FIGURE2_COMPACT_NOTES.md`

## Figure 2 story layout and behavior-stat alternatives

- `figures/Figure2_story.pdf`
- `figures/Figure2_story.svg`
- `figures/Figure2_behavior_candidate_stats.pdf`
- `FIGURE2_STORY_NOTES.md`

## Mean intrinsic reward course

- `figures/01b_online_intrinsic_reward_course.pdf`
- `figures/01b_online_intrinsic_reward_course.svg`
- `FIGURE2_INTRINSIC_REWARD_NOTES.md`

## Earlier Figure 2 layout trial

- `figures/Figure2_fiddle_with_fields.pdf`
- `figures/Figure2_fiddle_with_fields.svg`
- `FIGURE2_LAYOUT_NOTES.md`

## cosyne_2027_behavior_secondary (2 plots)

- `figures/candidates/cosyne_2027_behavior_secondary/figures/own_minus_random_decoder1_candidates.pdf`
- `figures/candidates/cosyne_2027_behavior_secondary/figures/own_minus_random_map_reliability.pdf`

## cosyne_2027_checkpoint_fields (102 plots)

- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/c01_effective_area_by_cutoff.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/c01_seed99_common_peak_density.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/c05_constant_hit_effective_area_by_cutoff.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/c05_temporal_hit_effective_area_by_cutoff.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/c15_effective_area_by_cutoff.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_active_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_active_pairwise_peak_distance_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_active_unique_peak_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_field_eligible_units.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_mean_active_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_mean_spatial_information_bits.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_mono_field_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_peak_effective_area.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_prethreshold_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/factorized_visited_cell_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_active_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_active_pairwise_peak_distance_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_active_unique_peak_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_field_eligible_units.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_mean_active_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_mean_spatial_information_bits.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_mono_field_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_prethreshold_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/paired_visited_cell_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_active_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_active_pairwise_peak_distance_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_active_unique_peak_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_field_eligible_units.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_mean_active_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_mean_spatial_information_bits.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_mono_field_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_prethreshold_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/common_panel_analysis/figures/worker_visited_cell_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/c01_seed17_checkpoint_course.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/c01_seed99_checkpoint_course.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/c05_seed17_checkpoint_course.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/c05_seed99_checkpoint_course.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/c15_seed17_checkpoint_course.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/c15_seed99_checkpoint_course.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_active_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_active_pairwise_peak_distance_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_active_unique_peak_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_field_eligible_units.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_mean_active_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_mean_spatial_information_bits.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_mono_field_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_prethreshold_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/factorized_visited_cell_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_active_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_active_pairwise_peak_distance_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_active_unique_peak_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_field_eligible_units.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_mean_active_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_mean_spatial_information_bits.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_mono_field_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_prethreshold_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/paired_visited_cell_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_active_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_active_pairwise_peak_distance_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_active_unique_peak_bins.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_field_eligible_units.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_mean_active_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_mean_spatial_information_bits.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_mono_field_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_prethreshold_map_cosine_mean.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/figures/worker_visited_cell_fraction.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/graph_trajectory_summary/graph_attempted_course_c05.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/graph_trajectory_summary/graph_attempted_course_c15.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/graph_trajectory_summary/graph_reachability_course_c05.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/graph_trajectory_summary/graph_reachability_course_c15.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/graph_trajectory_summary/trajectory_visited_course_c01.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/graph_trajectory_summary/trajectory_visited_course_c05.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/graph_trajectory_summary/trajectory_visited_course_c15.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/worker_timing_summary/worker_representation_graph.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/worker_timing_summary/worker_reward_exposure.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/worker_timing_summary/worker_trajectory_reliability.pdf`
- `figures/candidates/cosyne_2027_checkpoint_fields/c01_constant_s3/summary/place_fields_COS27_C01_CONSTANT_S99__00_COS27_C01_CONSTANT_S99__COS27_C01_CONSTANT__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c01_constant_s3/summary/pre_threshold_logits_COS27_C01_CONSTANT_S99__00_COS27_C01_CONSTANT_S99__COS27_C01_CONSTANT__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c01_temporal_s3/summary/place_fields_COS27_C01_TEMPORAL_S99__00_COS27_C01_TEMPORAL_S99__COS27_C01_TEMPORAL__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c01_temporal_s3/summary/pre_threshold_logits_COS27_C01_TEMPORAL_S99__00_COS27_C01_TEMPORAL_S99__COS27_C01_TEMPORAL__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c05_pushpull_s3/summary/place_fields_COS27_C05_CONSTANT_TEMPORAL_S99__00_COS27_C05_CONSTANT_TEMPORAL_S99__COS27_C05_CONSTANT_TEMPORAL__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c05_pushpull_s3/summary/place_fields_COS27_C05_TEMPORAL_TEMPORAL_S99__00_COS27_C05_TEMPORAL_TEMPORAL_S99__COS27_C05_TEMPORAL_TEMPORAL__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c05_pushpull_s3/summary/pre_threshold_logits_COS27_C05_CONSTANT_TEMPORAL_S99__00_COS27_C05_CONSTANT_TEMPORAL_S99__COS27_C05_CONSTANT_TEMPORAL__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c05_pushpull_s3/summary/pre_threshold_logits_COS27_C05_TEMPORAL_TEMPORAL_S99__00_COS27_C05_TEMPORAL_TEMPORAL_S99__COS27_C05_TEMPORAL_TEMPORAL__s99__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c15_available/summary/place_fields_COS27_C15_CONSTANT_S123__00_COS27_C15_CONSTANT_S123__COS27_C15_CONSTANT__s123__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c15_available/summary/place_fields_COS27_C15_TEMPORAL_S123__00_COS27_C15_TEMPORAL_S123__COS27_C15_TEMPORAL__s123__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c15_available/summary/pre_threshold_logits_COS27_C15_CONSTANT_S123__00_COS27_C15_CONSTANT_S123__COS27_C15_CONSTANT__s123__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/c15_available/summary/pre_threshold_logits_COS27_C15_TEMPORAL_S123__00_COS27_C15_TEMPORAL_S123__COS27_C15_TEMPORAL__s123__f100007936.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/graphs/COS27_C05_CONSTANT_CONSTANT_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/graphs/COS27_C05_CONSTANT_TEMPORAL_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/graphs/COS27_C05_TEMPORAL_CONSTANT_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/graphs/COS27_C05_TEMPORAL_TEMPORAL_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/graphs/COS27_C15_CONSTANT_S17.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/graphs/COS27_C15_TEMPORAL_S17.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C01_CONSTANT_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C01_TEMPORAL_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C05_CONSTANT_CONSTANT_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C05_CONSTANT_TEMPORAL_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C05_TEMPORAL_CONSTANT_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C05_TEMPORAL_TEMPORAL_S99.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C15_CONSTANT_S17.png`
- `figures/candidates/cosyne_2027_checkpoint_fields/selected_figures/trajectories/COS27_C15_TEMPORAL_S17.png`

## cosyne_2027_common_panel_layers (6 plots)

- `figures/candidates/cosyne_2027_common_panel_layers/absolute_ca3.pdf`
- `figures/candidates/cosyne_2027_common_panel_layers/absolute_decoder_1.pdf`
- `figures/candidates/cosyne_2027_common_panel_layers/absolute_decoder_2.pdf`
- `figures/candidates/cosyne_2027_common_panel_layers/worker_difference_ca3.pdf`
- `figures/candidates/cosyne_2027_common_panel_layers/worker_difference_decoder_1.pdf`
- `figures/candidates/cosyne_2027_common_panel_layers/worker_difference_decoder_2.pdf`

## cosyne_2027_compact_figures (13 plots)

- `figures/candidates/cosyne_2027_compact_figures/01_online_spatial_course.pdf`
- `figures/candidates/cosyne_2027_compact_figures/02_behavior_expression.pdf`
- `figures/candidates/cosyne_2027_compact_figures/02_behavior_expression_absolute.pdf`
- `figures/candidates/cosyne_2027_compact_figures/02_behavior_info_values_and_delta.pdf`
- `figures/candidates/cosyne_2027_compact_figures/02_behavior_reliability_values_and_delta.pdf`
- `figures/candidates/cosyne_2027_compact_figures/02_credit_presence.pdf`
- `figures/candidates/cosyne_2027_compact_figures/03_encoder_credit_deltas.pdf`
- `figures/candidates/cosyne_2027_compact_figures/03_encoder_credit_original_values.pdf`
- `figures/candidates/cosyne_2027_compact_figures/03_encoder_map_cosine_original_values.pdf`
- `figures/candidates/cosyne_2027_compact_figures/04_worker_coverage_values_and_delta.pdf`
- `figures/candidates/cosyne_2027_compact_figures/04_worker_frozen_info_values_and_delta.pdf`
- `figures/candidates/cosyne_2027_compact_figures/04_worker_online_info_values_and_delta.pdf`
- `figures/candidates/cosyne_2027_compact_figures/04_worker_timing_factorized.pdf`

## cosyne_2027_intrinsic_reward_course (1 plots)

- `figures/candidates/cosyne_2027_intrinsic_reward_course/01b_online_intrinsic_reward_course.pdf`

## cosyne_2027_online_wandb (10 plots)

- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_active_fraction.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_map_cosine.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_mono_field_fraction.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_peak_nearest_neighbor_distance.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_peaks_per_active_unit.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_primary_secondary_peak_distance.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_spatial_information.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_unique_peak_bins.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/factorized_visited_cell_fraction.pdf`
- `figures/candidates/cosyne_2027_online_wandb/figures/intact_spatial_information_mean_sem.pdf`

## cosyne_2027_snapshot_peak_spread (7 plots)

- `figures/candidates/cosyne_2027_snapshot_peak_spread/figures/example_valid_peaks_gaussian.pdf`
- `figures/candidates/cosyne_2027_snapshot_peak_spread/figures/gaussian_bandwidth_sensitivity.pdf`
- `figures/candidates/cosyne_2027_snapshot_peak_spread/figures/gaussian_effective_area_by_cutoff.pdf`
- `figures/candidates/cosyne_2027_snapshot_peak_spread/figures/gaussian_gini_by_cutoff.pdf`
- `figures/candidates/cosyne_2027_snapshot_peak_spread/figures/paired_behavior_graph_checks.pdf`
- `figures/candidates/cosyne_2027_snapshot_peak_spread/figures/pairwise_distance_by_cutoff.pdf`
- `figures/candidates/cosyne_2027_snapshot_peak_spread/figures/valid_peaks_by_cutoff.pdf`

## cosyne_2027_temporal_credit_layers (6 plots)

- `figures/candidates/cosyne_2027_temporal_credit_layers/encoder_paired_ca3.pdf`
- `figures/candidates/cosyne_2027_temporal_credit_layers/encoder_paired_decoder_1.pdf`
- `figures/candidates/cosyne_2027_temporal_credit_layers/encoder_paired_decoder_2.pdf`
- `figures/candidates/cosyne_2027_temporal_credit_layers/worker_paired_ca3.pdf`
- `figures/candidates/cosyne_2027_temporal_credit_layers/worker_paired_decoder_1.pdf`
- `figures/candidates/cosyne_2027_temporal_credit_layers/worker_paired_decoder_2.pdf`
