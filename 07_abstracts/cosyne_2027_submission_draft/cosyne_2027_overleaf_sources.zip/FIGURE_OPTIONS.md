# Included figures

All three figures used by `main.tex` have their PDFs and SVG originals here. The earlier full ~10 MB optional figure-candidate library is preserved in the repository file `cosyne_2027_overleaf_sources_full_backup_20261012.zip`. This compact project imports directly into Overleaf. The separate repository `build_overleaf_package.py` can regenerate the expanded library.
