# Figures in this Overleaf project

`main.tex` uses `figures/Figure1.pdf` and `figures/Figure2.pdf`. Matching editable SVGs are at the project root.

Distinct Figure 2 evidence variants are `figures/Figure2_story.pdf` (response maps) and `figures/Figure2_story_peaks.pdf` (paired peak maps). Their notes and source manifests are included. Individual icons, behavior plots, trajectory tiles, atlases, tables, and the selected palette source remain available for later figure work.
