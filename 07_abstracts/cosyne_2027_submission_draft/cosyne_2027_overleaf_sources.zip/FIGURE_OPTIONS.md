# Figures in this compact Overleaf project

The two PDFs below are used by `main.tex`; each has an SVG source.

- `figures/architecture.pdf`
- `figures/results_sections.pdf`

The compact editable Figure 2 layout trial is at `figures/Figure2_tetris.svg`, with a PDF and preview beside it. Read `FIGURE2_COMPACT_NOTES.md` and the longer `FIGURE2_LAYOUT_NOTES.md` for its caption. The earlier taller trial is also included.

The expanded candidate library is in the repository's full archive.
