# Figures in this compact Overleaf project

The two PDFs below are used by `main.tex`; each has an SVG source.

- `figures/architecture.pdf`
- `figures/results_sections.pdf`

The editable Figure 2 layout trial is at `figures/Figure2_fiddle_with_fields.svg`, with a PDF and preview beside it. Read `FIGURE2_LAYOUT_NOTES.md` before using its caption.

The expanded candidate library is in the repository's full archive.
