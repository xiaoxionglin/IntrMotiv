# Figures in this compact Overleaf project

The two PDFs below are used by `main.tex`; each has an SVG source.

- `figures/architecture.pdf`
- `figures/results_sections.pdf`

The compact editable Figure 2 layout trial is at `figures/Figure2_tetris.svg`, with a PDF and preview beside it. A tighter option with two empty side slots is `figures/Figure2_tetris_sidebar.pdf`. Read `FIGURE2_COMPACT_NOTES.md` and the longer `FIGURE2_LAYOUT_NOTES.md` for its caption. A story layout with trajectories and swappable behavior statistics is `figures/Figure2_story.pdf`; a peak-map sidebar option with paired temporal/control peak maps is `figures/Figure2_story_peaks.pdf`. See `FIGURE2_STORY_NOTES.md` and `FIGURE2_STORY_PEAKS_NOTES.md`. An E-free layout with metric icons is `figures/Figure2_story_icons.pdf` and `FIGURE2_STORY_ICONS_NOTES.md`. Its three 65-fragment trajectory tiles are separate editable SVGs under `figures/trajectory_examples/`; see `FIGURE2_TRAJECTORY_CANDIDATES_NOTES.md`. Five tiny metric icons and their preview are in `figures/Figure2_metric_icon_*.pdf` and `FIGURE2_METRIC_ICONS_NOTES.md`. The earlier taller trial is also included. A matching five-seed mean intrinsic-reward training course is available at `figures/01b_online_intrinsic_reward_course.pdf`, with a log-y variant at `figures/01c_online_intrinsic_reward_course_log.pdf`; see `FIGURE2_INTRINSIC_REWARD_NOTES.md`.

The expanded candidate library is in the repository's full archive.
