# Figures in this compact Overleaf project

The two PDFs below are used by `main.tex`; each has an SVG source.

- `figures/architecture.pdf`
- `figures/results_sections.pdf`

The expanded candidate library is in the repository's full archive.
